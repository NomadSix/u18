// File Name: Main.cpp
// Author: Devon Schimming
// Student ID: h865r773
// Assignment Number: 1

#include "test_interface.hpp"
typedef unsigned int uint;

int main() {
	runTests();
	return 0;
}
